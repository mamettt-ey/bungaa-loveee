# Bungaa Love Page

Website romantis sederhana untuk Bungaa (Gwen) ❤️  
Dibuat dengan HTML + CSS + JS.  

## Cara pakai di GitHub Pages:
1. Upload semua file ini ke repository GitHub kamu.
2. Masuk ke Settings -> Pages.
3. Pilih branch: main, folder: /(root).
4. Tunggu beberapa menit, lalu buka: https://<username>.github.io/<nama-repo>/
